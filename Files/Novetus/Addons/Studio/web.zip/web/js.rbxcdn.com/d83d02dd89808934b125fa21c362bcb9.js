var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

;// bundle: Widgets___DropdownMenu___9f333eefa0a43b38692f486f67376440_m
;// files: modules/Widgets/DropdownMenu.js

;// modules/Widgets/DropdownMenu.js
Roblox.define("Widgets.DropdownMenu",["jQuery"],function(n){function t(){var t=n(".button").not(".init");t.each(function(){var i=n(this).outerWidth()-parseInt(n(this).css("border-left-width"))-parseInt(n(this).css("border-right-width")),t;n(this).siblings(".dropdown-list").css("min-width",i),t=n(this).siblings('.dropdown-list[data-align="right"]').first(),t.css("right",0)}),n(".dropdown-list").hide(),t.click(function(){return n(this).hasClass("active")?(n(this).removeClass("active"),n(this).siblings(".dropdown-list").hide()):(n(this).addClass("active"),n(this).siblings(".dropdown-list").show()),!1}),n(document).click(function(){t.removeClass("active"),n(".dropdown-list").hide()}),t.addClass("init")}return{InitializeDropdown:t}});


}
/*
     FILE ARCHIVED ON 05:12:24 Feb 20, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 02:15:55 Jan 10, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 93.738
  exclusion.robots: 0.197
  exclusion.robots.policy: 0.189
  cdx.remote: 0.067
  esindex: 0.009
  LoadShardBlock: 36.816 (3)
  PetaboxLoader3.datanode: 68.638 (5)
  CDXLines.iter: 33.398 (3)
  load_resource: 148.236 (2)
  PetaboxLoader3.resolve: 74.595 (2)
*/