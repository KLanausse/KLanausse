var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

;// bundle: jQuery___f96d183221b7e5fc88ce682603a50c3a_m
;// files: modules/jQuery.js

;// modules/jQuery.js
if(typeof jQuery!="undefined"&&jQuery.fn.jquery!="1.7.2")var conflict=!0;Roblox.define("jQuery","/js/jquery/jquery-1.7.2.min.js",function(){return conflict?jQuery.noConflict(!0):jQuery});


}
/*
     FILE ARCHIVED ON 05:12:24 Feb 20, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:51:09 Jan 10, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 389.53
  exclusion.robots: 0.2
  exclusion.robots.policy: 0.192
  cdx.remote: 0.065
  esindex: 0.008
  LoadShardBlock: 267.161 (3)
  PetaboxLoader3.datanode: 297.18 (5)
  CDXLines.iter: 34.442 (3)
  load_resource: 162.24 (2)
  PetaboxLoader3.resolve: 117.419 (2)
*/