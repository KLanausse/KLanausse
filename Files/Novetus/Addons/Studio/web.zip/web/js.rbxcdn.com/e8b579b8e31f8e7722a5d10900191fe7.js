var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

;// bundle: Widgets___HierarchicalDropdown___8ecab16c30958fcd20bb1fb76e433da4_m
;// files: modules/Widgets/HierarchicalDropdown.js

;// modules/Widgets/HierarchicalDropdown.js
Roblox.define("Widgets.HierarchicalDropdown",["jQuery"],function(n){function i(){var t=n(".roblox-hierarchicaldropdownbutton"),r=n(".roblox-hierarchicaldropdown"),i=!1;t.mouseover(function(){t.addClass("hover")}),t.mouseout(function(){i||t.removeClass("hover")}),t.click(function(){return r.fadeOut("fast"),i?(i=!1,t.removeClass("hover")):(t.addClass("hover"),r.fadeIn("fast"),i=!0),!1}),n(document).click(function(){r.fadeOut("fast"),i=!1,t.removeClass("hover")})}function t(t){var i=t.width();t.find("li").each(function(t,r){r=n(r),r.outerWidth()>i&&(i=r.outerWidth())}),t.find("li").each(function(t,r){r=n(r),r.width()<i&&r.width(i)})}return n(function(){var u=0,f=0,i=n(".roblox-hierarchicaldropdown"),o=i.find("li"),r=i.find("li ul"),e=i.find("li ul[hover=true]");r.mouseover(function(){n(this).attr("hover","true")}),r.mouseout(function(){n(this).attr("hover","false")}),o.mouseover(function(){var o=n(this).data("delay"),u;o!="ignore"&&e.length==0&&(n(this).attr("hover","true"),o!="never"&&(f==1||o=="always")?window.setTimeout(function(){if(e.length==0){var n=i.find("li[hover=true] ul");r.hide(),n.length!=0&&(n.show(),t(n))}},1e3):(r.hide(),u=n(this).find("ul"),u.show(),t(u)))}),o.mouseout(function(){n(this).removeAttr("hover")}),i.mouseleave(function(){window.setTimeout(function(){r.hide()},100),u=0,f=0}),i.mousemove(function(n){var t=u;u=n.pageX,(t==u||t==0)&&(f=0),f=t<u?1:-1})}),{InitializeDropdown:i}});


}
/*
     FILE ARCHIVED ON 14:27:40 Feb 21, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 04:39:46 Jan 10, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 156.981
  exclusion.robots: 0.157
  exclusion.robots.policy: 0.15
  cdx.remote: 0.067
  esindex: 0.008
  LoadShardBlock: 89.329 (3)
  PetaboxLoader3.datanode: 151.438 (5)
  CDXLines.iter: 14.51 (3)
  load_resource: 1447.426 (2)
  PetaboxLoader3.resolve: 1362.396 (2)
*/